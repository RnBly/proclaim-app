# Proclaim - 성경 읽기 및 묵상 앱

<div align="center">

![Flutter](https://img.shields.io/badge/Flutter-02569B?style=for-the-badge&logo=flutter&logoColor=white)
![Firebase](https://img.shields.io/badge/Firebase-FFCA28?style=for-the-badge&logo=firebase&logoColor=black)
![GitHub Pages](https://img.shields.io/badge/GitHub%20Pages-222222?style=for-the-badge&logo=github&logoColor=white)

**매일의 말씀 읽기와 묵상을 돕는 성경 앱**

[🌐 라이브 데모](https://rnbly.github.io/proclaim-app/) | [📖 문서](#기능) | [🚀 시작하기](#시작하기)

</div>

---

## 📖 소개

Proclaim은 성경읽기표를 기반으로 한 체계적인 성경 읽기와 개인 묵상 기록을 지원하는 Flutter 웹 앱입니다.

### ✨ 주요 특징

- 📅 **성경읽기표**: 1년 1독 계획에 따른 체계적인 성경 읽기
- 📖 **3단 구성**: 시편 → 구약 → 신약 순서로 매일의 말씀 제공
- 🌙 **한 달 통독**: 매월 시편과 구약·신약 통독 지원
- 🌐 **다국어 지원**: 한글 개역개정 + ESV 영문 번역
- ✍️ **묵상 기록**: 구절별 하이라이트 및 개인 묵상 작성
- 📱 **PWA 지원**: 모바일 홈 화면 추가 가능
- 🔐 **소셜 로그인**: Google, Kakao 로그인 지원

---

## 🎯 주요 기능

### 1. 📖 일일 성경 읽기
- 오늘 날짜의 읽기 계획 자동 표시
- 시편 → 구약 → 신약 순서의 3단 구성
- 좌우 스와이프로 간편한 페이지 전환
- 구절 선택 및 복사 기능

### 2. 🌙 한 달 통독
- 매월 1일~30일 통독 계획
- 시편 / 구·신약 페이지 분리
- 진도에 맞춘 체계적인 읽기

### 3. 📚 성경 본문 모드
- 창세기 1장부터 시작
- 장별 전체 본문 읽기
- 책/장 자유 선택 네비게이션
- 좌우 스와이프 장 이동

### 4. ✍️ 묵상 기능
- 구절별 색상 하이라이트 (5가지 색상)
- 개인 묵상 기록 및 관리
- 하이라이트된 구절 길게 눌러 묵상 확인
- 묵상 수정 및 삭제

### 5. ⚙️ 사용자 설정
- 한글/영문/대조 번역 전환
- 제목/본문 글씨 크기 조절
- 설정 자동 저장

---

## 🛠️ 기술 스택

### Frontend
- **Flutter Web** - UI 프레임워크
- **Provider** - 상태 관리
- **SharedPreferences** - 로컬 설정 저장

### Backend & Data
- **Firebase Authentication** - 사용자 인증
- **Cloud Firestore** - 묵상 데이터 저장
- **Google Sheets API** - 읽기 계획 데이터
- **GitHub Pages** - 정적 호스팅

### Development
- **GitHub Actions** - CI/CD 자동 배포
- **Android Studio** - 개발 환경

---

## 📂 프로젝트 구조

```
proclaim-app/
├── lib/
│   ├── main.dart                 # 앱 진입점
│   ├── screens/                  # 화면
│   │   ├── home_screen.dart      # 메인 화면 (일일 읽기)
│   │   ├── monthly_reading_screen.dart  # 한 달 통독
│   │   ├── bible_reader_screen.dart     # 성경 본문 모드
│   │   └── login_screen.dart     # 로그인 화면
│   ├── widgets/                  # 재사용 위젯
│   │   ├── bible_page.dart       # 성경 본문 페이지 표시
│   │   ├── bible_selection_dialog.dart  # 성경 책/장/절 선택 다이얼로그
│   │   ├── color_selection_dialog.dart  # 묵상 하이라이트 색상 선택
│   │   ├── copy_dialog.dart      # 구절 복사 형식 선택 (한글/영문/대조)
│   │   ├── date_picker_dialog.dart      # 날짜 선택 다이얼로그
│   │   ├── meditation_view_dialog.dart  # 묵상 내용 조회 다이얼로그
│   │   ├── meditation_writing_dialog.dart  # 묵상 작성 다이얼로그
│   │   ├── reading_mode_dialog.dart     # 읽기 모드 선택 (일일/한달)
│   │   ├── settings_dialog.dart  # 설정 다이얼로그 (글꼴/역본)
│   │   ├── translation_dialog.dart      # 역본 선택 다이얼로그
│   │   └── verse_selection_dialog.dart  # 묵상할 구절 선택 다이얼로그
│   ├── services/                 # 비즈니스 로직
│   │   ├── bible_service.dart    # 성경 데이터 관리
│   │   ├── auth_service.dart     # 인증 관리
│   │   ├── meditation_service.dart  # 묵상 관리
│   │   └── preferences_service.dart # 설정 관리
│   ├── models/                   # 데이터 모델
│   │   ├── bible_book.dart
│   │   ├── bible_reading.dart
│   │   └── meditation.dart
│   └── config/                   # 설정 파일
│       └── secrets.dart          # API 키 (Git 제외)
├── assets/                       # 리소스
│   ├── bible_kor.json            # 한글 성경
│   ├── bible_esv.json            # ESV 영문 성경
│   └── icons/                    # 앱 아이콘
├── web/                          # 웹 설정
│   ├── index.html
│   └── manifest.json             # PWA 설정
└── .github/
    └── workflows/
        └── deploy.yml            # 자동 배포 설정
```

---

## 🚀 시작하기

### 📋 사전 요구사항

- Flutter SDK (3.0.0 이상)
- Dart SDK
- Android Studio / VS Code
- Firebase 프로젝트
- Google Cloud Console 프로젝트

### 🔧 설치 및 실행

1. **저장소 클론**
```bash
git clone https://github.com/RnBly/proclaim-app.git
cd proclaim-app
```

2. **의존성 설치**
```bash
flutter pub get
```

3. **환경 설정**

`lib/config/secrets.dart` 파일 생성:
```dart
class Secrets {
  // Firebase
  static const String firebaseApiKey = 'YOUR_FIREBASE_API_KEY';
  static const String firebaseAppId = 'YOUR_FIREBASE_APP_ID';
  static const String firebaseMessagingSenderId = 'YOUR_SENDER_ID';
  static const String firebaseProjectId = 'YOUR_PROJECT_ID';
  static const String firebaseAuthDomain = 'YOUR_AUTH_DOMAIN';
  static const String firebaseStorageBucket = 'YOUR_STORAGE_BUCKET';
  
  // Google Sheets
  static const String oldTestamentSheetId = 'YOUR_OT_SHEET_ID';
  static const String psalmsSheetId = 'YOUR_PSALMS_SHEET_ID';
  static const String newTestamentSheetId = 'YOUR_NT_SHEET_ID';
  
  // OAuth
  static const String googleClientId = 'YOUR_GOOGLE_CLIENT_ID';
  static const String kakaoJsKey = 'YOUR_KAKAO_JS_KEY';
  static const String kakaoNativeAppKey = 'YOUR_KAKAO_NATIVE_KEY';
}
```

4. **로컬 실행**
```bash
flutter run -d chrome
```

5. **빌드**
```bash
flutter build web --release
```

---

## 🔑 환경 변수 설정

### Firebase 설정
1. [Firebase Console](https://console.firebase.google.com/)에서 프로젝트 생성
2. Authentication 활성화 (Google, Email/Password)
3. Firestore Database 생성
4. 웹 앱 등록 후 구성 정보 복사

### Google Sheets API(비활성화)
1. [Google Cloud Console](https://console.cloud.google.com/) 프로젝트 생성
2. Google Sheets API 활성화
3. 읽기표 스프레드시트 생성 및 공유
4. 스프레드시트 ID 복사

### Kakao 로그인
1. [Kakao Developers](https://developers.kakao.com/)에서 앱 생성
2. JavaScript 키 발급
3. 플랫폼 설정에 웹 사이트 도메인 등록

---

## 📊 데이터 구조

### Google Sheets (읽기 계획)
```
날짜 | 책 | 시작장 | 끝장 | 구절범위
1/1  | 창 | 1      | 2    | 
1/2  | 창 | 3      | 4    | 
...
```

### Firestore (묵상 데이터)
```javascript
meditations/{meditationId}
{
  userId: string,
  verses: [
    { book: string, chapter: number, verse: number, text: string }
  ],
  content: string,
  highlightColor: string,
  createdAt: timestamp,
  updatedAt: timestamp
}
```

---

## 🚢 배포

### GitHub Pages 자동 배포

1. **Repository Secrets 설정**
```
Settings → Secrets and variables → Actions → New repository secret
```

필요한 Secrets:
- `FIREBASE_API_KEY`
- `FIREBASE_APP_ID`
- `FIREBASE_MESSAGING_SENDER_ID`
- `FIREBASE_PROJECT_ID`
- `FIREBASE_AUTH_DOMAIN`
- `FIREBASE_STORAGE_BUCKET`
- `OLD_TESTAMENT_SHEET_ID`
- `PSALMS_SHEET_ID`
- `NEW_TESTAMENT_SHEET_ID`
- `GOOGLE_CLIENT_ID`
- `KAKAO_JS_KEY`
- `KAKAO_NATIVE_APP_KEY`

2. **GitHub Actions 권한 설정**
```
Settings → Actions → General → Workflow permissions
✅ Read and write permissions
✅ Allow GitHub Actions to create and approve pull requests
```

3. **배포**
```bash
git push origin main
```

GitHub Actions가 자동으로 빌드 및 배포를 진행합니다.

---

## 📱 PWA 설치

### iOS (Safari)
1. Safari에서 앱 접속
2. 공유 버튼 탭
3. "홈 화면에 추가" 선택

### Android (Chrome)
1. Chrome에서 앱 접속
2. 메뉴 → "홈 화면에 추가"
3. 설치 확인

---

## 🎨 커스터마이징

### 색상 변경
`lib/config/meditation_colors.dart`에서 묵상 하이라이트 색상 수정:
```dart
static const Map<String, Color> colors = {
  'yellow': Color(0xFFFFF59D),
  'green': Color(0xFFA5D6A7),
  // ...
};
```

### 글꼴 크기 기본값
`lib/services/preferences_service.dart`:
```dart
static const double _defaultTitleFontSize = 24.0;
static const double _defaultBodyFontSize = 18.0;
```

---

## 🐛 트러블슈팅

### 문제: 성경 본문이 표시되지 않음
**해결**: `assets/bible_kor.json`, `assets/bible_esv.json` 파일 확인

### 문제: Google Sheets 데이터 로드 실패
**해결**: 
1. 스프레드시트 공유 설정 확인 (링크가 있는 모든 사용자)
2. Sheet ID가 정확한지 확인
3. 브라우저 콘솔에서 CORS 오류 확인

### 문제: Firebase 인증 오류
**해결**:
1. Firebase Console에서 도메인 승인 목록 확인
2. `localhost`, `127.0.0.1`, 배포 도메인 추가
3. OAuth 리디렉션 URI 확인

---

## 📝 라이선스

이 프로젝트는 개인 사용 및 학습 목적으로 제작되었습니다.

- **성경 텍스트**: 
  - 한글: 대한성서공회 개역개정
  - 영문: ESV (English Standard Version)
- **읽기표**: 공개 리소스 기반

---

## 🤝 기여

기여를 환영합니다! 

1. Fork the Project
2. Create your Feature Branch (`git checkout -b feature/AmazingFeature`)
3. Commit your Changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the Branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

---

## 📧 연락처

프로젝트 관련 문의: [GitHub Issues](https://github.com/RnBly/proclaim-app/issues)

---

## 🙏 감사의 말

- 성경읽기표를 제공해주신 분들께
- Flutter 및 Firebase 커뮤니티
- 성경 번역 제공: 대한성서공회, Crossway (ESV)

---

<div align="center">

**Made with ❤️ for daily Bible reading**

⭐ Star this repo if it helped you!

</div>