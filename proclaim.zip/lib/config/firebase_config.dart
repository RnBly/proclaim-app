import 'package:firebase_core/firebase_core.dart';

class FirebaseConfig {
  static const firebaseConfig = FirebaseOptions(
      apiKey: "AIzaSyCQR6chmzinFrATx_mi3I0LdzaIcnzUntY",
      authDomain: "proclaim-app-3ea73.firebaseapp.com",
      projectId: "proclaim-app-3ea73",
      storageBucket: "proclaim-app-3ea73.firebasestorage.app",
      messagingSenderId: "1086075135355",
      appId: "1:1086075135355:web:4415bd93f29e1e945a49de",
      measurementId: "G-F70DHRFY8H"
  );
}