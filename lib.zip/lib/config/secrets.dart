/**
 * secrets.dart
 * 
 * 외부 서비스 연동에 필요한 API 키 및 URL 정보를 관리하는 파일
 * 
 * 역할:
 * - Google Sheets 연동 정보 (읽기 계획 데이터)
 * - GitHub Raw URL (성경 본문 JSON 파일)
 * - CSV Export URL 생성 함수
 * 
 * 주의사항:
 * - 민감한 정보는 포함되지 않지만, 공개 저장소에서는 관리 필요
 * - SPREADSHEET_ID 변경 시 Google Sheets 권한 확인 필요
 * 
 * 관련 서비스:
 * - Google Sheets: 맥체인 성경읽기표 데이터
 * - GitHub: 성경 본문 JSON 파일 호스팅
 */

/**
 * Secrets 클래스
 * 
 * 앱에서 사용하는 외부 리소스 URL과 설정값을 관리
 * 모든 멤버는 static const로 선언되어 컴파일 타임에 결정됨
 */
class Secrets {
  // ========== Google Sheets 설정 ==========
  
  /**
   * Spreadsheet ID
   * 
   * Google Sheets의 고유 식별자
   * URL 형식: https://docs.google.com/spreadsheets/d/[이_ID값]/edit
   * 
   * 이 스프레드시트에는 맥체인 성경읽기 계획이 포함되어 있음:
   * - Old Testament 시트: 구약 읽기 계획
   * - Psalms 시트: 시편 읽기 계획
   * - New Testament 시트: 신약 읽기 계획
   * 
   * 참고: 실제로는 Google Drive 파일 ID로 사용됨
   */
  static const String SPREADSHEET_ID = '1dzHDX6LYR0qzkijQ_bWMBlSQGhGrMj4S';

  /**
   * 구약성경 읽기 계획 시트 이름
   * 
   * Google Sheets 내 탭 이름
   * 1년 366일 동안의 구약 읽기 계획이 포함됨
   */
  static const String OLD_TESTAMENT_SHEET = 'Old Testament';
  
  /**
   * 시편 읽기 계획 시트 이름
   * 
   * Google Sheets 내 탭 이름
   * 1년 366일 동안의 시편 읽기 계획이 포함됨
   */
  static const String PSALMS_SHEET = 'Psalms';
  
  /**
   * 신약성경 읽기 계획 시트 이름
   * 
   * Google Sheets 내 탭 이름
   * 1년 366일 동안의 신약 읽기 계획이 포함됨
   */
  static const String NEW_TESTAMENT_SHEET = 'New Testament';

  /**
   * 한 달 통독 계획 시트 이름 (구약 + 신약)
   * 
   * Google Sheets 내 탭 이름
   * 30일 동안의 구약과 신약 통독 계획이 포함됨
   */
  static const String MONTHLY_READING_SHEET = '1month';

  /**
   * 한 달 통독 계획 시트 이름 (시편)
   * 
   * Google Sheets 내 탭 이름
   * 30일 동안의 시편 통독 계획이 포함됨
   */
  static const String MONTHLY_PSALMS_SHEET = '1month_ps';

  // ========== GitHub Raw URLs ==========
  
  /**
   * 한글 성경 본문 JSON URL
   * 
   * GitHub Repository에 호스팅된 전체 성경 본문 (개역개정)
   * proclaim-app repository의 main 브랜치에서 직접 로드
   * 
   * 파일 구조:
   * {
   *   "창세기": {
   *     "1": {
   *       "1": "태초에 하나님이 천지를 창조하시니라",
   *       ...
   *     }
   *   },
   *   ...
   * }
   * 
   * 사용 위치:
   * - BibleService.initialize(): 앱 시작 시 한번 로드
   */
  static const String BIBLE_JSON_URL =
      'https://raw.githubusercontent.com/RnBly/proclaim-app/main/assets/bible.json';

  /**
   * ESV 영어 성경 본문 JSON URL
   * 
   * GitHub Repository에 호스팅된 전체 성경 본문 (English Standard Version)
   * proclaim-app repository의 main 브랜치에서 직접 로드
   * 
   * 파일 구조:
   * {
   *   "Genesis": {
   *     "1": {
   *       "1": "In the beginning, God created the heavens and the earth.",
   *       ...
   *     }
   *   },
   *   ...
   * }
   * 
   * 사용 위치:
   * - BibleService.loadESVBible(): ESV 버전 필요 시 로드
   */
  static const String BIBLE_ESV_JSON_URL =
      'https://raw.githubusercontent.com/RnBly/proclaim-app/main/assets/bible_esv.json';

  // ========== Google Sheets CSV Export URL 생성 ==========
  
  /**
   * Google Sheets를 CSV 형식으로 Export하는 URL 생성
   * 
   * Google Sheets는 특정 URL 패턴을 사용하면 CSV로 직접 Export 가능
   * 
   * @param sheetName 시트 이름 (예: 'Old Testament', 'Psalms', 'New Testament')
   * @return CSV Export URL
   * 
   * URL 구조:
   * - /gviz/tq: Google Visualization API
   * - tqx=out:csv: 출력 형식을 CSV로 지정
   * - sheet={sheetName}: 특정 시트 선택
   * 
   * 사용 예:
   * ```dart
   * String url = Secrets.getSheetCsvUrl('Old Testament');
   * // 결과: https://docs.google.com/spreadsheets/d/1dzHDX6LYR0qzkijQ_bWMBlSQGhGrMj4S/gviz/tq?tqx=out:csv&sheet=Old Testament
   * ```
   * 
   * 사용 위치:
   * - BibleService: 읽기 계획 데이터를 CSV로 가져올 때 사용
   */
  static String getSheetCsvUrl(String sheetName) {
    return 'https://docs.google.com/spreadsheets/d/$SPREADSHEET_ID/gviz/tq?tqx=out:csv&sheet=$sheetName';
  }
}
